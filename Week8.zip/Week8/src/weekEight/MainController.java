package weekEight;

import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * the MainController class initializes a LinkedList of Student objects. It then
 * add Student objects with attributes values specified by the user. These
 * Students are added to the LinkedList, sorted, and written to a file.
 * 
 * @author: Aerionna Stephenson
 */
public class MainController {
	static Scanner scanner = new Scanner(System.in);

	/**
	 * This main method initiates a Linked List, adds Student objects based on the
	 * user's specifications, sorts those Objects in ascending order according to
	 * the Student's name, and write them to a file.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		LinkedList<Student> students = new LinkedList<>();
		System.out.println("How many students would you like to add?");
		int num = checkForInt();
		scanner.nextLine();
		for (int i = 0; i < num; i++) {
			students.add(enterStudentInfo());
		}

		SelectSortAlgor.selectionSort(students, new NameComparator());
		writeToFile(students);
	}

	/**
	 * The user is asked to provided the values for the attributes for a student
	 * Object. It also ensures that these values are not empty
	 * 
	 * @return a Student objects with those given values
	 */
	public static Student enterStudentInfo() {
		String name = "";
		String address = "";

		do {
			System.out.println("Enter the Student's name?");
			name = scanner.nextLine().trim();
			if (name.isEmpty()) {
				System.out.println("The name cannot empty. Please enter an actual name.");
			}
		} while (name.isEmpty());

		do {
			System.out.println("Enter the Student's address?");
			address = scanner.nextLine().trim();
			if (address.isEmpty()) {
				System.out.println("The address cannot empty. Please enter an actual address.");
			}
		} while (address.isEmpty());

		System.out.println("Enter the Student's GPA?");
		double GPA = checkForValidGPA();

		Student a = new Student(name, address, GPA);

		return a;
	}

	/**
	 * this checks to make sure that the user entered a double. If not, they are
	 * prompted to try again.
	 * 
	 * @return a double that is entered by the user
	 */
	public static double checkForDouble() {
		while (true) {
			try {
				return scanner.nextDouble();
			} catch (Exception e) {
				System.out.println("You have entered an invalid input. Please try again, but make sure it's a double.");
				scanner.next();
			}
		}
	}

	/**
	 * this checks to make sure that the user entered an integer. If not, they are
	 * prompted to try again.
	 * 
	 * @return a integer that is entered by the user
	 */
	public static int checkForInt() {
		while (true) {
			try {
				return scanner.nextInt();
			} catch (Exception e) {
				System.out
						.println("You have entered an invalid input. Please try again, but make sure it's a integer.");
				scanner.next();
			}
		}
	}

	/**
	 * this checks that the value given by the user for the GPA is in between 0 and
	 * 4.0.
	 * 
	 * @return a double value for the GPA entered by the user
	 */
	public static double checkForValidGPA() {
		while (true) {
			double GPA = checkForDouble();
			scanner.nextLine();

			if (GPA >= 0 && GPA <= 4.0) {
				return GPA;
			} else {
				System.out.println("The GPA must be between 0 and 4.0. Please enter a valid GPA.");
			}
		}
	}

	/**
	 * this writes the given sorted linked linkedList to a file
	 * 
	 * @param students a linkedList of Student objects
	 */
	public static void writeToFile(LinkedList<Student> students) {
		try {
			FileWriter f = new FileWriter("studentlog.txt");
			for (Student s : students) {
				f.write(s.toString());
				f.write("\n");
			}

			f.close();
			System.out.println("Successfully wrote to the file.");
		} catch (IOException e) {
			System.out.println("There has been a error.");
			;
		}

	}
}
