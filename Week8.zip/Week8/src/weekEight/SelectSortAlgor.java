package weekEight;

import java.util.Comparator;
import java.util.LinkedList;

/**
 * SelectSortAlgor performs selection sort on an LinkedList of Student objects
 * using the specified Comparator class.
 * 
 * This class demonstrates a manual implementation of the selection sort
 * algorithm. It does not use Java’s built-in sort methods.
 * 
 * @author Aerionna Stephenson
 */
public class SelectSortAlgor {
	/**
	 * Sorts an LinkedList of Student objects using selection sort and the provided
	 * comparator.
	 * 
	 * @param myStudent  the LinkedList of students to be sorted
	 * @param comparator the comparator used to determine sort order
	 */
	public static void selectionSort(LinkedList<Student> myStudent,
			@SuppressWarnings("rawtypes") Comparator comparator) {
		// determines the positioning of the remaining smallest elements
		for (int i = 0; i < myStudent.size() - 1; i++) {
			// Assume the smallest item's index is i
			int minPosition = i;
			// inner loop looks through unsorted list to find the a smaller object to
			// replace the current smallest object
			for (int a = i + 1; a < myStudent.size(); a++) {
				@SuppressWarnings("unchecked")
				// compares the current element with the smallest known element
				int result = comparator.compare(myStudent.get(a), myStudent.get(minPosition));

				// if the current student comes before the smallest student
				if (result < 0) {
					// the student's index becomes the new position for the smallest student
					minPosition = a;
				}
			}
			// the current element is swapped with the smallest element

			// this is just a temp object to hold the current student
			Student temp = myStudent.get(i);
			// the smallest student is places in position i
			myStudent.set(i, myStudent.get(minPosition));
			// Move the original student to where the smallest one was
			myStudent.set(minPosition, temp);
		}

	}

}
