package weekEight;

/**
 * The Student class contain the attributes, constructor, getters, and setter
 * for a Student Object. It also features utilizes input validation to ensure
 * that the inputs provided by the user are valid and within range.
 * 
 * @author Aerionna Stephenson
 */
public class Student {
	private String name;
	private String address;
	private double GPA;

	/**
	 * creates a student object with the specified values. The values of each
	 * attribute are set using the attribute's setter.
	 * 
	 * @param name    the name of the student
	 * @param address the student's address
	 * @param GPA     the student's GPA
	 */
	public Student(String name, String address, double GPA) {
		setName(name);
		setAddress(address);
		setGPA(GPA);
	}

	/**
	 * this returns the student's name
	 * 
	 * @return the student's name
	 */
	public String getName() {
		return name;
	}

	/**
	 * This method sets the students name using the given value.
	 * 
	 * @param name the is the value that the name attribute will be set to
	 * @throws IllegalArgumentException if the name is null or empty
	 */
	public void setName(String name) {
		if (name == null || name.trim().isEmpty()) {
			throw new IllegalArgumentException("This field cannot be empty. The Student must have a name.");
		}
		this.name = name;
	}

	/**
	 * this returns the student's address
	 * 
	 * @return the student's address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * This method sets the students address using the given value.
	 * 
	 * @param address the is the value that the address attribute will be set to
	 * @throws IllegalArgumentException if the address is null or empty
	 */
	public void setAddress(String address) {
		if (address == null || address.trim().isEmpty()) {
			throw new IllegalArgumentException("This field cannot be empty. The Student must have an address.");
		}
		this.address = address;
	}

	/**
	 * this returns the student's GPA
	 * 
	 * @return the student's GPA
	 */
	public double getGPA() {

		return GPA;
	}

	/**
	 * This method sets the students GPA using the given value.
	 * 
	 * @param gPA the is the value that the GPA attribute will be set to
	 * @throws IllegalArgumentException if the gPA is less than 0 and greater than
	 *                                  4.0
	 */
	public void setGPA(double gPA) {
		if (gPA < 0 || gPA > 4.0) {
			throw new IllegalArgumentException("The GPA must be between 0 and 4.0.");
		}
		this.GPA = gPA;
	}

	/**
	 * this creates a string representation of the student object
	 */
	@Override
	public String toString() {
		return "Student: name = " + name + ", address = " + address + ", GPA = " + GPA;
	}

}
